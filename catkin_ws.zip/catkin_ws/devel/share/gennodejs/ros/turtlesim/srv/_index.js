
"use strict";

let Spawn = require('./Spawn.js')
let SetPen = require('./SetPen.js')
let TeleportAbsolute = require('./TeleportAbsolute.js')
let TeleportRelative = require('./TeleportRelative.js')
let Kill = require('./Kill.js')

module.exports = {
  Spawn: Spawn,
  SetPen: SetPen,
  TeleportAbsolute: TeleportAbsolute,
  TeleportRelative: TeleportRelative,
  Kill: Kill,
};
