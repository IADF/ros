#include "ros/ros.h"
#include "std_msgs/String.h"

#include "sstream"//输出流文件

int main(int argc, char **argv)
{
	//ros初始化
	ros::init(argc, argv, "talker");

	//创建节点句柄
	ros::NodeHandle n;

	//创建一个Puclisher，发布名为chatter的topic，消息类型为——std_msgs
	ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);

	//设置循环的频率
	ros::Rate loop_rate(10);


	int count = 0;
	while(ros::ok())
	{
		//初始化std_msgs::String类型的消息
		std_msgs::String msg;

		//字符串输出刘对象声明
		std::stringstream ss;

		ss << "hello world" << count;

		msg.data = ss.str();

		//发布消息
		ROS_INFO("%s", msg.data.c_str());	
		chatter_pub.publish(msg);

		//循环等待所有的回调函数
		ros::spinOnce();

		//休眠等待周期
		loop_rate.sleep();
		++count;//统计发布消息的次数
	}
	return 0;
}
