
"use strict";

let Person = require('./Person.js');
let DoDishesGoal = require('./DoDishesGoal.js');
let DoDishesActionFeedback = require('./DoDishesActionFeedback.js');
let DoDishesActionResult = require('./DoDishesActionResult.js');
let DoDishesActionGoal = require('./DoDishesActionGoal.js');
let DoDishesResult = require('./DoDishesResult.js');
let DoDishesAction = require('./DoDishesAction.js');
let DoDishesFeedback = require('./DoDishesFeedback.js');

module.exports = {
  Person: Person,
  DoDishesGoal: DoDishesGoal,
  DoDishesActionFeedback: DoDishesActionFeedback,
  DoDishesActionResult: DoDishesActionResult,
  DoDishesActionGoal: DoDishesActionGoal,
  DoDishesResult: DoDishesResult,
  DoDishesAction: DoDishesAction,
  DoDishesFeedback: DoDishesFeedback,
};
