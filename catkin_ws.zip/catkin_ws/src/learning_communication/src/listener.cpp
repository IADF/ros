#include "ros/ros.h"
#include "std_msgs/String.h"

//回调函数（用于打印出接收到的消息）
void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
  ROS_INFO("I heard: [%s]", msg->data.c_str());
}

int main(int argc, char **argv)
{
	//启动ros
	ros::init(argc, argv, "listener");

	ros::NodeHandle n;

	//创建接受者
	ros::Subscriber sub = n.subscribe("chatter", 1000, chatterCallback);

	ros::spin();

	return 0;
}
